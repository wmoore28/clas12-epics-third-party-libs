#ifndef TYPEDEFS_HH
#define TYPEDEFS_HH

#ifdef defBool
  typedef int bool;
#endif

#endif
