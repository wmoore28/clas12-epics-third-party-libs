#ifndef INCVERSION
#define INCVERSION
#define smixxVersion "v47r1"
#define smixxDate "12-September-2014:11:49"
#endif /* INCVERSION */
