#ifndef PARAMETERS_HH
#define PARAMETERS_HH
#define MAXRECL 129
#define MAXSUBOBJECTS 1
#endif
//#define DEBUG
