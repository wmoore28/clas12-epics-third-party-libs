#include "smiuirtl.h"

int main(argc,argv)
int argc;
char **argv;
{
	argc = argc;

	smiui_kill(argv[1]);
	return (0);
}
