
#ifndef INCCXXTRANSLATORVERSION
#define INCCXXTRANSLATORVERSION

#define CXXTranslatorVersion " CXXTranslator Version v16  Date: 27 October 2003 "

#endif /* INCCXXTRANSLATORVERSION */
