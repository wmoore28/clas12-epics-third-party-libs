// boolitem.cxx: implementation of the BoolItem class.
//
//                                                B. Franek
//                                           28 February 2000
//////////////////////////////////////////////////////////////////////

#include "boolitem.hxx"

#include "stdlib.h"
#include "name.hxx"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
BoolItem::BoolItem()
{
	return;
}

BoolItem::~BoolItem()
{
    return;
}


