/*
//-----------------------------------------------------------------------
//                         Attributes  Class
//                                                 B. Franek
//                                                 5 July 1999
//-----------------------------------------------------------------------
//
#include <stdlib.h>
#include <assert.h>
#include "attributes.hxx"

//--------------------------- Constructors -------------------------------

Attributes::Attributes () 
	:SMLUnit("attr",2) {
	return;
}

Attributes::~Attributes() {
    delete _pSMLcode;
}

  
void Attributes::translate() {
//	cout << " Attributes Translate not implemented yet\n"; return;
    return;
}
*/
