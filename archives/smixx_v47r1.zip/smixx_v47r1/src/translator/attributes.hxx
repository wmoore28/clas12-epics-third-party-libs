/*
//-----------------------------------------------------------------------
//                         State  Attributes
//                                                 B. Franek
//                                                 5 July 1999
//-----------------------------------------------------------------------
//
#ifndef ATTRIBUTES_HH
#define ATTRIBUTES_HH
#include "smlunit.hxx"

class  Attributes : public SMLUnit {

   public :

      Attributes ();

      virtual ~Attributes();

      virtual void translate();

   protected :

};
#endif
*/
