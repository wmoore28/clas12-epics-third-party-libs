#ifndef __SMIXXDEFS
#define __SMIXXDEFS
#define SMIXX_VERSION 4701
#endif
